using Assignment2PRN221_BlogPost.ViewModels;
using BlogPostBO.Model;
using BlogPostService;
using BlogPostService.Interface;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Assignment2PRN221_BlogPost.Pages.Admin.Blogs
{
    public class AddModel : PageModel
    {
        [BindProperty]
        public AddBlogModel AddBlogModelRequest { get; set; }
        private readonly IBlogService blogService;
        public AddModel() => blogService = new  BlogService();
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            var blog = new BlogPost()
            {
                Heading = AddBlogModelRequest.Heading,
                Content = AddBlogModelRequest.Content,
                PageTitle = AddBlogModelRequest.PageTitle,
                ShortDescription = AddBlogModelRequest.ShortDescription,
                ImageUrl = AddBlogModelRequest.ImageUrl,
                UrlHandle = AddBlogModelRequest.UrlHandle,
                PublishedDate = AddBlogModelRequest.PublishedDate,
                AccountId = 1
            };
            blogService.AddBlogPost(blog);
            return RedirectToPage("/Admin/Blogs/List");
        }
    }
}
