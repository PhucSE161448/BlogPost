using BlogPostBO.Model;
using BlogPostService.Interface;
using BlogPostService;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Assignment2PRN221_BlogPost.Pages.Admin.Blogs
{
    public class EditModel : PageModel
    {
        private readonly IBlogService blogService;
        [BindProperty]
        public BlogPost BlogPost { get; set; }
        public EditModel()
        {
            blogService = new BlogService();
        }
        public void OnGet(int id)
        {
            BlogPost = blogService.GetAll().Find(x => x.Id == id);
        }

        public IActionResult OnPostEdit()
        {
            var blog = blogService.GetAll().Find(x => x.Id == BlogPost.Id);
            if (blog != null)
            {
                blog.Heading = BlogPost.Heading;
                blog.PageTitle = BlogPost.PageTitle;
                blog.Content = BlogPost.Content;
                blog.ShortDescription = BlogPost.ShortDescription;
                blog.ImageUrl = BlogPost.ImageUrl;
                blog.UrlHandle = BlogPost.UrlHandle;
                blog.PublishedDate = BlogPost.PublishedDate;
                blog.Visible = BlogPost.Visible;
                blog.AccountId = BlogPost.AccountId;
            }
            blogService.EditBlogPost(blog);
            return RedirectToPage("/Admin/Blogs/List");
        }

        public IActionResult OnPostDelete()
        {
            var blog = blogService.GetAll().Find(x => x.Id == BlogPost.Id);
            if(blog != null)
            {
                blogService.DeleteBlogPost(blog.Id);
                return RedirectToPage("/Admin/Blogs/List");
            }
            return Page();
        }
    }
}
